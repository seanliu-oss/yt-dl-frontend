This is a GUI frontend for youtube-dl package, written in python and kivy.
A .apk has been built with buildozer for Android.
It *should* be cross platform but I only tested it on Windows and Android.
